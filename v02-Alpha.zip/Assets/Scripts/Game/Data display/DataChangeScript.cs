using UnityEngine;
using TMPro;
using System.Collections.Generic;
using System.Linq;

public class DataChangeScript : MonoBehaviour
{
    [Header("UI Elements")]
    public TextMeshProUGUI MoneyChangeDisplay;
    public TextMeshProUGUI StressChangeDisplay;
    public TextMeshProUGUI HappinessChangeDisplay;
    public TextMeshProUGUI FoodChangeDisplay;
    public TextMeshProUGUI EnergyChangeDisplay;
    public TextMeshProUGUI TimeChangeDisplay;
    public TextMeshProUGUI KnowledgeChangeDisplay;

    [Header("Player Data")]
    public PlayerData PlayerData;

    private Dictionary<string, int> currentChanges = new Dictionary<string, int>();
    private Dictionary<string, TextMeshProUGUI> changeDisplays = new Dictionary<string, TextMeshProUGUI>();

    private void Start()
    {
        PlayerData = FindFirstObjectByType<PlayerData>();

        InitializeDisplayDictionary();
        
        ClearAllPreviews();
    }

    private void InitializeDisplayDictionary()
    {
        changeDisplays.Clear();
        if (MoneyChangeDisplay != null)
            changeDisplays.Add("money", MoneyChangeDisplay);
        if (StressChangeDisplay != null)
            changeDisplays.Add("stress", StressChangeDisplay);
        if (HappinessChangeDisplay != null)
            changeDisplays.Add("happiness", HappinessChangeDisplay);
        if (FoodChangeDisplay != null)
            changeDisplays.Add("food", FoodChangeDisplay);
        if (EnergyChangeDisplay != null)
            changeDisplays.Add("energy", EnergyChangeDisplay);
        if (TimeChangeDisplay != null)
            changeDisplays.Add("time", TimeChangeDisplay);
        if (TimeChangeDisplay != null)
            changeDisplays.Add("exp", KnowledgeChangeDisplay);
    }

    public void PreviewResults(Dictionary<string, int> characteristics)
    {
        currentChanges = new Dictionary<string, int>(characteristics);
        
        foreach (var change in characteristics)
        {
            if (changeDisplays.ContainsKey(change.Key.ToLower()))
            {
                UpdateChangeDisplay(change.Key.ToLower(), change.Value);
            }
        }
    }

    private void UpdateChangeDisplay(string characteristic, int value)
    {
        if (changeDisplays.TryGetValue(characteristic, out TextMeshProUGUI display))
        {
            display.gameObject.SetActive(true);
            if (value == 0)
            {
                display.text = "- 0";
            }
            else
            {
                string sign = value > 0 ? "+" : "";
                string color = value > 0 ? "#00FF00" : "#FF0000"; // Зеленый для положительных, красный для отрицательных
                if (characteristic == "time" || characteristic == "stress")
                    color = value > 0 ? "#FF0000" : "#00FF00";
                if (characteristic == "time"){
                    int hours = value / 60;
                    int minutes = value % 60;
                    
                    display.text = $"- <color={color}>{sign}{hours:D2}:{minutes:D2}</color>";
                }
                else
                    display.text = $"- <color={color}>{sign}{value}</color>";
            }
        }
    }

    public void ClearAllPreviews()
    {
        foreach (var display in changeDisplays.Values)
        {
            if (display != null)
            {
                display.text = "";
                display.gameObject.SetActive(false);
            }
        }
        currentChanges.Clear();
    }

    public void ApplyChanges()
    {
        if (PlayerData == null)
        {
            Debug.LogWarning("PlayerData не назначен!");
            return;
        }

        foreach (var change in currentChanges)
        {
            ApplyCharacteristicChange(change.Key, change.Value);
        }
        
        ClearAllPreviews();
    }

    private void ApplyCharacteristicChange(string characteristic, int value)
    {
        switch (characteristic.ToLower())
        {
            case "money":
                PlayerData.CurrentMoney += value;
                break;
            case "stress":
                if (PlayerData.CurrentStress + value >= 0 || PlayerData.CurrentStress + value <= 10)
                    PlayerData.CurrentStress += value;
                break;
            case "happiness":
                if (PlayerData.CurrentHappiness + value >= 0 || PlayerData.CurrentHappiness + value <= 10)
                    PlayerData.CurrentHappiness += value;
                break;
            case "food":
                PlayerData.CurrentFood += value;
                break;
            case "energy":
                if (PlayerData.CurrentEnergy + value >= 0 || PlayerData.CurrentEnergy + value <= 10)
                    PlayerData.CurrentEnergy += value;
                break;
            case "time":
                PlayerData.CurrentTime += value;
                break;
            case "exp":
                if (PlayerData.CurrentKnowledge + value < 100)
                    PlayerData.CurrentKnowledge += value;
                break;
            default:
                Debug.LogWarning($"Неизвестная характеристика: {characteristic}");
                break;
        }
    }

    public void ModifyPlayerData(Dictionary<string, int> changes)
    {
        PreviewResults(changes);
        ApplyChanges();
    }
}