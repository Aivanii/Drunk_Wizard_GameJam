using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class MapControlScript : MonoBehaviour
{
    public DataChangeScript DataChanger;
    public PlayerData PlayerData;
    public SaveManager SaveManager;
    
    public void Home_OnHover(){
        DataChanger.PreviewResults(new Dictionary<string, int>(){
            {"money",0},{"stress", 0},{"food",0},{"happiness", 0},{"energy", 0},{"time",0}});
    }
    public void Home_OnHoverExit(){
        DataChanger.ClearAllPreviews();
    }
    public void Home_OnClick(){
        DataChanger.ApplyChanges();
        SaveManager.SaveGame(PlayerData);
        SceneManager.LoadScene("Room");
    }

    public void University_OnHover(){
        DataChanger.PreviewResults(new Dictionary<string, int>(){
            {"money",0},{"stress", 0},{"food",0},{"happiness", 0},{"energy", -1},{"time",150}});
    }
    public void University_OnHoverExit(){
        DataChanger.ClearAllPreviews();
    }
    public void University_OnClick(){
        DataChanger.ApplyChanges();
        SaveManager.SaveGame(PlayerData);
        SceneManager.LoadScene("University");
    }

    public void Store_OnHover(){
        DataChanger.PreviewResults(new Dictionary<string, int>(){
            {"money",-40},{"stress", 0},{"food",1},{"happiness", 0},{"energy", -1},{"time",30}});
    }
    public void Store_OnHoverExit(){
        DataChanger.ClearAllPreviews();
    }
    public void Store_OnClick(){
        DataChanger.ApplyChanges();
        SaveManager.SaveGame(PlayerData);
    }

    public void Job_OnHover(){
        DataChanger.PreviewResults(new Dictionary<string, int>(){
            {"money",0},{"stress", 0},{"food", 0},{"happiness", 0},{"energy", -1},{"time",120}});
    }
    public void Job_OnHoverExit(){
        DataChanger.ClearAllPreviews();
    }
    public void Job_OnClick(){
        DataChanger.ApplyChanges();
        SaveManager.SaveGame(PlayerData);
        //SceneManager.LoadScene("University");
    }
}
