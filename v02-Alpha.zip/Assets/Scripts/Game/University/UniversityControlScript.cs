using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class UniversityControlScript : MonoBehaviour
{
    public DataChangeScript DataChanger;
    public PlayerData PlayerData;
    public SaveManager SaveManager;
    
    public void Library_OnHover(){
        DataChanger.PreviewResults(new Dictionary<string, int>(){
            {"stress", 0},{"exp",5},{"happiness", 0},{"energy", -2},{"time",240}});
    }
    public void Library_OnHoverExit(){
        DataChanger.ClearAllPreviews();
    }
    public void Library_OnClick(){
        DataChanger.ApplyChanges();
        SaveManager.SaveGame(PlayerData);
        SceneManager.LoadScene("Room");
    }

    public void Auditory_OnHover(){
        DataChanger.PreviewResults(new Dictionary<string, int>(){
            {"stress", 1},{"exp",10},{"happiness", -1},{"energy", -1},{"time",150}});
    }
    public void Auditory_OnHoverExit(){
        DataChanger.ClearAllPreviews();
    }
    public void Auditory_OnClick(){
        DataChanger.ApplyChanges();
        SaveManager.SaveGame(PlayerData);
        SceneManager.LoadScene("University");
    }
    // TODO: если останется время, сделать экзамен
    /*
    public void Exam_OnHover(){
        DataChanger.PreviewResults(new Dictionary<string, int>(){
            {"stress", 3},{"exp",20},{"happiness", 0},{"energy", -1},{"time",30}});
    }
    public void Exam_OnHoverExit(){
        DataChanger.ClearAllPreviews();
    }
    public void Exam_OnClick(){
        DataChanger.ApplyChanges();
        SaveManager.SaveGame(PlayerData);
    }
    */

    public void Exit_OnHover(){
        DataChanger.PreviewResults(new Dictionary<string, int>(){
            {"stress", 0},{"food", 0},{"happiness", 0},{"energy", 0},{"time",150}});
    }
    public void Exit_OnHoverExit(){
        DataChanger.ClearAllPreviews();
    }
    public void Exit_OnClick(){
        DataChanger.ApplyChanges();
        SaveManager.SaveGame(PlayerData);
        SceneManager.LoadScene("Map");
    }
}
