using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class RoomControlScript : MonoBehaviour
{
    public DataChangeScript DataChanger;
    public PlayerData PlayerData;
    public SaveManager SaveManager;
    public void Exit_OnClick()
    {
        SaveManager.SaveGame(PlayerData);
        SceneManager.LoadScene("Map");
    }

    public void Refrigirator_OnHover(){
        DataChanger.PreviewResults(new Dictionary<string, int>(){
            {"stress", -1},{"food",-1},{"happiness", 1},{"energy",2},{"time",30}});
    }
    public void Refrigirator_OnHoverExit(){
        DataChanger.ClearAllPreviews();
    }
    public void Refrigirator_OnClick(){
        if (PlayerData.CurrentFood > 0)
            DataChanger.ApplyChanges();
    }

    public void TV_OnHover(){
        DataChanger.PreviewResults(new Dictionary<string, int>(){
            {"stress", -1},{"food",0},{"happiness", 1},{"energy",0},{"time",60}});
    }
    public void TV_OnHoverExit(){
        DataChanger.ClearAllPreviews();
    }
    public void TV_OnClick(){
        DataChanger.ApplyChanges();
    }

    public void Bed_OnHover(){
        DataChanger.PreviewResults(new Dictionary<string, int>(){
            {"stress", -1},{"food",0},{"happiness", 0},{"energy", 1},{"time",120}});
    }
    public void Bed_OnHoverExit(){
        DataChanger.ClearAllPreviews();
    }
    public void Bed_OnClick(){
        DataChanger.ApplyChanges();
    }
}
