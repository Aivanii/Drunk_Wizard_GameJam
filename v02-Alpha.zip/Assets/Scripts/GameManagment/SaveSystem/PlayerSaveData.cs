using UnityEngine;

[System.Serializable]
public class PlayerSaveData
{
    // Player data
    public int CurrentStress = 0;
    public int MaxStress = 10;
    
    public int CurrentHappiness = 10;
    public int MaxHappiness = 10;
    
    public int CurrentEnergy = 10;
    public int MaxEnergy = 10;
    
    public int CurrentKnowledge = 0;
    public int MaxKnowledge = 100;
    
    public int CurrentMoney = 100;
    
    // Time data
    public int CurrentDeadLine = 0;
    public int MaxDeadLine = 62;
    public int CurrentTime = 8 * 60;
    public int MaxTime;
    public int CurrentFood = 2;
}
