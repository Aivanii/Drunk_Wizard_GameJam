using UnityEngine;

public class PlayerData : MonoBehaviour
{
    [Header("Player data")]
        public int CurrentStress = 0;
        public int MaxStress = 10;

        public int CurrentHappiness = 10;
        public int MaxHappiness = 10;

        public int CurrentEnergy = 10;
        public int MaxEnergy = 10;
        
        public int CurrentKnowledge = 0;
        public int MaxKnowledge = 100;


        public MoneyManager MoneyManager;
        private int _CurrentMoney = 100;
        public int CurrentMoney
        {
            get { return _CurrentMoney; }
            set
            {
                if (_CurrentMoney != value)
                {
                    _CurrentMoney = value;
                    if (MoneyManager != null)
                        MoneyManager.OnDataChanged(value);
                }
            }
        }
    [Header("Impendible Doom")]
        public TimeManager TimeManager;

        public int CurrentDeadLine = 0;
        public int MaxDeadLine = 62;

        private int _CurrentTime = 8 * 60;
        public int CurrentTime
        {
            get { return _CurrentTime; }
            set
            {
                if (_CurrentTime != value)
                {
                    _CurrentTime = value;
                    if (TimeManager != null)
                        TimeManager.OnDataChanged();
                }
            }
        }
        public int MaxTime;

        public int CurrentFood = 2;
        // TODO: если будет время, реализовать смерть от голода
        //public int LastMealTime = 8 * 60;
    private void Start(){
        MaxTime = MaxDeadLine * 1440;
    }

    public PlayerSaveData ToSaveData()
    {
        return new PlayerSaveData
        {
            CurrentStress = this.CurrentStress,
            MaxStress = this.MaxStress,
            CurrentHappiness = this.CurrentHappiness,
            MaxHappiness = this.MaxHappiness,
            CurrentEnergy = this.CurrentEnergy,
            MaxEnergy = this.MaxEnergy,
            CurrentKnowledge = this.CurrentKnowledge,
            MaxKnowledge = this.MaxKnowledge,
            CurrentMoney = this.CurrentMoney,
            CurrentDeadLine = this.CurrentDeadLine,
            MaxDeadLine = this.MaxDeadLine,
            CurrentTime = this.CurrentTime,
            MaxTime = this.MaxTime,
            CurrentFood = this.CurrentFood
        };
    }

    public void FromSaveData(PlayerSaveData saveData)
    {
        this.CurrentStress = saveData.CurrentStress;
        this.MaxStress = saveData.MaxStress;
        this.CurrentHappiness = saveData.CurrentHappiness;
        this.MaxHappiness = saveData.MaxHappiness;
        this.CurrentEnergy = saveData.CurrentEnergy;
        this.MaxEnergy = saveData.MaxEnergy;
        this.CurrentKnowledge = saveData.CurrentKnowledge;
        this.MaxKnowledge = saveData.MaxKnowledge;
        this.CurrentMoney = saveData.CurrentMoney;
        this.CurrentDeadLine = saveData.CurrentDeadLine;
        this.MaxDeadLine = saveData.MaxDeadLine;
        this.CurrentTime = saveData.CurrentTime;
        this.MaxTime = saveData.MaxTime;
        this.CurrentFood = saveData.CurrentFood;

        if (MoneyManager != null)
            MoneyManager.OnDataChanged(this.CurrentMoney);
        
        if (TimeManager != null)
            TimeManager.OnDataChanged();
    }
}
