using System.IO;
using UnityEngine;

public class SaveManager : MonoBehaviour
{
    private string savePath;
    
    void Awake()
    {
        savePath = Path.Combine(Application.persistentDataPath, "playerdata.json");
    }
    
    public void SaveGame(PlayerData playerData)
    {
        PlayerSaveData saveData = playerData.ToSaveData();
        string json = JsonUtility.ToJson(saveData, true);
        File.WriteAllText(savePath, json);
        Debug.Log("Game saved to: " + savePath);
    }
    
    public PlayerSaveData LoadGame()
    {
        if (File.Exists(savePath))
        {
            string json = File.ReadAllText(savePath);
            PlayerSaveData data = JsonUtility.FromJson<PlayerSaveData>(json);
            Debug.Log("Game loaded from: " + savePath);
            return data;
        }
        else
        {
            Debug.Log("No save file found, creating new data");
            return new PlayerSaveData();
        }
    }
}