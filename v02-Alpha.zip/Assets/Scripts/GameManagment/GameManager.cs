using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    
    public PlayerData PlayerData;
    public MoneyManager MoneyManager;
    public TimeManager TimeManager;
    private SaveManager SaveManager;
    
    void Awake()
    {
        SaveManager = GetComponent<SaveManager>();
        InitializePlayer();
    }
    
    void InitializePlayer()
    {
        PlayerSaveData loadedData = SaveManager.LoadGame();
        
        if (PlayerData == null)
            PlayerData = FindFirstObjectByType<PlayerData>();
        
        if (PlayerData != null)
        {
            PlayerData.FromSaveData(loadedData);
        }
    }
    
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F5))
            SaveGame();
    }

    public void SaveGame()
    {
        if (PlayerData != null)
        {
            SaveManager.SaveGame(PlayerData);
        }
    }

    public void OnSceneLoaded()
    {
        if (PlayerData != null)
        {
            PlayerData.MoneyManager = MoneyManager;
            PlayerData.TimeManager = TimeManager;
            
            if (MoneyManager != null)
                MoneyManager.OnDataChanged(PlayerData.CurrentMoney);
            
            if (TimeManager != null)
                TimeManager.OnDataChanged();
        }
    }
}